/**
 * WhatBreaks Pre-Mortem Lambda Function
 * 
 * This Lambda function generates pre-mortem reports using Amazon Bedrock.
 * It receives infrastructure change descriptions and returns failure scenarios.
 */

const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime');

const bedrockClient = new BedrockRuntimeClient({ region: process.env.AWS_REGION || 'us-east-1' });

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  try {
    // Parse input
    const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    const { description, changeType, currentState, proposedState, trafficPatterns } = body;

    // Validate input
    if (!description || description.length < 50) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Description must be at least 50 characters' }),
      };
    }

    // Generate pre-mortem using Bedrock
    const preMortem = await generatePreMortem({
      description,
      changeType: changeType || 'infrastructure',
      currentState,
      proposedState,
      trafficPatterns,
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(preMortem),
    };
  } catch (error) {
    console.error('Error generating pre-mortem:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message || 'Failed to generate pre-mortem' }),
    };
  }
};

async function generatePreMortem(input) {
  const prompt = buildPreMortemPrompt(input);

  const params = {
    modelId: 'anthropic.claude-3-5-sonnet-20241022-v2:0',
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      max_tokens: 4000,
      messages: [
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
    }),
  };

  const command = new InvokeModelCommand(params);
  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));

  const fullReport = responseBody.content[0].text;

  // Parse structured data from the report
  return {
    id: `pm-${Date.now()}`,
    timestamp: new Date().toISOString(),
    input,
    changeSummary: input.description.substring(0, 200),
    fullReport,
    // Additional structured fields would be parsed from the AI response
  };
}

function buildPreMortemPrompt(input) {
  return `You are a reliability engineering expert performing a pre-mortem analysis. 

CRITICAL INSTRUCTION: Assume this infrastructure change HAS ALREADY CAUSED a production outage in the future. Your job is to work backwards from that failure and explain how it happened.

INFRASTRUCTURE CHANGE:
${input.description}

${input.currentState ? `CURRENT STATE:\n${input.currentState}\n` : ''}
${input.proposedState ? `PROPOSED STATE:\n${input.proposedState}\n` : ''}
${input.trafficPatterns ? `TRAFFIC PATTERNS:\n${input.trafficPatterns}\n` : ''}

Generate a detailed pre-mortem report with the following sections:

1. ASSUMED OUTCOME
   - Severity (critical/major/moderate)
   - Duration of outage
   - Impact description
   - Affected users/services

2. TRIGGERING EVENT
   - What specific event triggered the failure?
   - When did it occur relative to the change? (T+Xh)
   - What was the root cause?

3. HIDDEN DEPENDENCIES
   - What assumptions were made that turned out to be wrong?
   - What dependencies were overlooked?
   - How did these contribute to the failure?

4. CASCADE TIMELINE
   - Provide a chronological timeline of how the failure cascaded
   - Include timestamps, events, causes, and effects
   - Note decision points where the failure could have been prevented

5. SYSTEM COUPLING
   - What unexpected couplings existed?
   - How did they amplify the failure?

6. PREVENTIVE ACTIONS
   - What specific actions could prevent this scenario?
   - Prioritize by impact and effort

Be specific, technical, and realistic. Use actual system behavior patterns.`;
}
